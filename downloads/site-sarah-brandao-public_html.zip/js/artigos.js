/* Artigos: lê artigos/artigos.json e monta a lista (início e página de artigos) e a página de cada artigo. */
(function () {
  "use strict";

  var MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function formatDate(iso) {
    var p = String(iso || "").split("-");
    if (p.length !== 3) return "";
    return Number(p[2]) + " de " + MESES[Number(p[1]) - 1] + " de " + p[0];
  }

  function slugify(s) {
    return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
      .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  }

  /* Markdown simples: ## títulos, parágrafos, **negrito**, *itálico*, [links](url), ![imagens](url), listas (- ou 1.) e > citações. */
  function inline(s) {
    // protege caracteres escapados pelo editor (ex.: \* ou \-) para não virarem formatação
    s = String(s).replace(/\\([\\`*_{}\[\]()#+\-.!>])/g, function (_, ch) { return '\u0001' + ch.charCodeAt(0) + '\u0002'; });
    return esc(s)
      .replace(/!\[([^\]]*)\]\(((?:https?:\/\/|\/)[^)\s]+)\)/g, '<img src="$2" alt="$1" loading="lazy">')
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/__(.+?)__/g, "<strong>$1</strong>")
      .replace(/\*(.+?)\*/g, "<em>$1</em>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+|mailto:[^)\s]+|tel:[^)\s]+)\)/g, function (_, t, u) {
        var ext = /^https?:/.test(u) ? ' target="_blank" rel="noopener"' : "";
        return '<a href="' + u + '"' + ext + ">" + t + "</a>";
      })
      .replace(/\u0001(\d+)\u0002/g, "&#$1;");
  }

  function markdown(md) {
    var blocks = String(md || "").replace(/\r\n/g, "\n").split(/\n{2,}/);
    return blocks.map(function (b) {
      var t = b.trim();
      if (!t) return "";
      var h = t.match(/^(#{1,4})\s+(.*)$/);
      if (h) { var lv = Math.max(2, h[1].length); return "<h" + lv + ">" + inline(h[2]) + "</h" + lv + ">"; }
      var lines = t.split("\n");
      if (lines.every(function (l) { return /^\s*[-*]\s+/.test(l); }))
        return "<ul>" + lines.map(function (l) { return "<li>" + inline(l.replace(/^\s*[-*]\s+/, "")) + "</li>"; }).join("") + "</ul>";
      if (lines.every(function (l) { return /^\s*\d+[.)]\s+/.test(l); }))
        return "<ol>" + lines.map(function (l) { return "<li>" + inline(l.replace(/^\s*\d+[.)]\s+/, "")) + "</li>"; }).join("") + "</ol>";
      if (lines.every(function (l) { return /^>\s?/.test(l); }))
        return "<blockquote><p>" + inline(lines.map(function (l) { return l.replace(/^>\s?/, ""); }).join(" ")) + "</p></blockquote>";
      return "<p>" + lines.map(inline).join("<br>") + "</p>";
    }).join("\n");
  }

  function load() {
    return fetch("artigos/artigos.json", { cache: "no-cache" })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (data) {
        var list = Array.isArray(data) ? data : (data && data.artigos) || [];
        list.forEach(function (a) { if (a && !a.slug) a.slug = slugify(a.titulo); });
        return list
          .filter(function (a) { return a && a.publicado !== false && a.slug && a.titulo; })
          .sort(function (a, b) { return String(b.data).localeCompare(String(a.data)); });
      });
  }

  function card(a) {
    var url = "artigo.html?a=" + encodeURIComponent(a.slug);
    return '<article class="article-card">' +
      '<p class="article-meta">' + (a.categoria ? "<span>" + esc(a.categoria) + "</span>" : "") +
      '<time datetime="' + esc(a.data) + '">' + formatDate(a.data) + "</time></p>" +
      '<h3><a href="' + url + '">' + esc(a.titulo) + "</a></h3>" +
      (a.resumo ? "<p>" + esc(a.resumo) + "</p>" : "") +
      '<a class="link-arrow" href="' + url + '" aria-hidden="true" tabindex="-1">Ler artigo <span>→</span></a>' +
      "</article>";
  }

  /* Seção "Artigos" da página inicial: mostra os 3 mais recentes; fica oculta se não houver nenhum. */
  var homeSection = document.getElementById("artigos");
  if (homeSection) {
    load().then(function (list) {
      if (!list.length) return;
      homeSection.querySelector(".articles-grid").innerHTML = list.slice(0, 3).map(card).join("");
      homeSection.hidden = false;
    }).catch(function () { /* sem artigos: a seção continua oculta */ });
  }

  /* Página com todos os artigos */
  var listPage = document.getElementById("lista-artigos");
  if (listPage) {
    load().then(function (list) {
      listPage.innerHTML = list.length
        ? list.map(card).join("")
        : '<p class="articles-empty">Em breve, novos artigos sobre direito internacional e imigração.</p>';
    }).catch(function () {
      listPage.innerHTML = '<p class="articles-empty">Não foi possível carregar os artigos agora.</p>';
    });
  }

  /* Página de um artigo: artigo.html?a=slug */
  var articlePage = document.getElementById("artigo");
  if (articlePage) {
    var slug = new URLSearchParams(location.search).get("a");
    load().then(function (list) {
      var a = list.filter(function (x) { return x.slug === slug; })[0];
      if (!a) {
        articlePage.querySelector(".article-title").textContent = "Artigo não encontrado";
        articlePage.querySelector(".prose").innerHTML = '<p>Este artigo não está disponível. <a href="artigos.html">Ver todos os artigos</a>.</p>';
        return;
      }
      document.title = a.titulo + " | Sarah Brandão Advocacia Internacional";
      var desc = document.querySelector('meta[name="description"]');
      if (desc && a.resumo) desc.setAttribute("content", a.resumo);
      articlePage.querySelector(".article-title").textContent = a.titulo;
      articlePage.querySelector(".article-meta").innerHTML =
        (a.categoria ? "<span>" + esc(a.categoria) + "</span>" : "") +
        '<time datetime="' + esc(a.data) + '">' + formatDate(a.data) + "</time>";
      articlePage.querySelector(".prose").innerHTML = markdown(a.conteudo);
    }).catch(function () {
      articlePage.querySelector(".prose").innerHTML = "<p>Não foi possível carregar o artigo agora.</p>";
    });
  }
})();
