(function () {
  "use strict";
  document.documentElement.classList.add("js");

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  var header = document.querySelector(".site-header");
  function headerOffset() { return (header ? header.offsetHeight : 0) + 16; }

  /* ---------- Ano no rodapé ---------- */
  var year = document.getElementById("ano");
  if (year) year.textContent = new Date().getFullYear();

  /* ---------- Rolagem suave (mouse e trackpad; no toque fica a rolagem nativa) ---------- */
  var lenis = null;
  if (!reduceMotion && typeof window.Lenis === "function") {
    lenis = new window.Lenis({ duration: 1.15, easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); }, smoothWheel: true });
    (function raf(time) { lenis.raf(time); requestAnimationFrame(raf); })(performance.now());
  }

  function scrollToTarget(target) {
    if (lenis) lenis.scrollTo(target, { offset: -headerOffset() });
    else {
      var y = target === 0 ? 0 : target.getBoundingClientRect().top + window.scrollY - headerOffset();
      window.scrollTo({ top: y, behavior: reduceMotion ? "auto" : "smooth" });
    }
  }

  /* Links internos (#secao) com a mesma rolagem suave e compensação do header */
  document.addEventListener("click", function (e) {
    var a = e.target.closest('a[href^="#"]');
    if (!a) return;
    var id = a.getAttribute("href");
    if (id === "#" || id.length < 2) return;
    var target = id === "#topo" || id === "#inicio" ? 0 : document.querySelector(id);
    if (target === null) return;
    e.preventDefault();
    scrollToTarget(target);
    if (id !== "#topo" && id !== "#inicio") history.replaceState(null, "", id);
  });

  /* ---------- Header: fundo de vidro ao rolar ---------- */
  function onScroll() { if (header) header.classList.toggle("is-scrolled", window.scrollY > 12); }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- Menu mobile ---------- */
  var toggle = document.querySelector(".menu-toggle");
  var nav = document.getElementById("menu");

  function setMenu(open) {
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
    nav.classList.toggle("is-open", open);
    document.body.style.overflow = open ? "hidden" : "";
    if (lenis) { if (open) lenis.stop(); else lenis.start(); }
  }
  if (toggle && nav) {
    toggle.addEventListener("click", function () { setMenu(toggle.getAttribute("aria-expanded") !== "true"); });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) setMenu(false); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("is-open")) { setMenu(false); toggle.focus(); }
    });
    window.matchMedia("(min-width: 1081px)").addEventListener("change", function (mq) { if (mq.matches) setMenu(false); });
  }

  /* ---------- Abas acessíveis (serviços e países) ---------- */
  function initTabs(tablist) {
    var tabs = Array.prototype.slice.call(tablist.querySelectorAll(':scope > [role="tab"]'));

    function select(tab, focus) {
      tabs.forEach(function (t) {
        var active = t === tab;
        var panel = document.getElementById(t.getAttribute("aria-controls"));
        t.classList.toggle("is-active", active);
        t.setAttribute("aria-selected", String(active));
        t.tabIndex = active ? 0 : -1;
        panel.hidden = !active;
        panel.classList.toggle("is-active", active);
      });
      if (focus) tab.focus();
      if (lenis) lenis.resize();
    }

    tabs.forEach(function (tab, i) {
      tab.addEventListener("click", function () { select(tab, false); });
      tab.addEventListener("keydown", function (e) {
        var next = null;
        if (e.key === "ArrowRight" || e.key === "ArrowDown") next = tabs[(i + 1) % tabs.length];
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") next = tabs[(i - 1 + tabs.length) % tabs.length];
        if (e.key === "Home") next = tabs[0];
        if (e.key === "End") next = tabs[tabs.length - 1];
        if (next) { e.preventDefault(); select(next, true); }
      });
    });
  }
  document.querySelectorAll('[role="tablist"]').forEach(initTabs);

  /* ---------- Link ativo no menu ---------- */
  if (nav && "IntersectionObserver" in window) {
    var links = Array.prototype.slice.call(nav.querySelectorAll('a[href^="#"]:not(.btn)'));
    var navObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        links.forEach(function (a) { a.classList.toggle("is-current", a.getAttribute("href") === "#" + entry.target.id); });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    links.forEach(function (a) { var s = document.querySelector(a.getAttribute("href")); if (s) navObserver.observe(s); });
  }

  /* ---------- Cards empilhados (áreas de atuação) ---------- */
  var cards = Array.prototype.slice.call(document.querySelectorAll(".stack-card"));
  cards.forEach(function (card, i) { card.style.setProperty("--i", i); });
  var ticking = false;
  function updateStack() {
    ticking = false;
    for (var i = 0; i < cards.length - 1; i++) {
      var cur = cards[i].getBoundingClientRect();
      var next = cards[i + 1].getBoundingClientRect();
      // quanto o próximo card já cobriu o atual (0 a 1)
      var p = (cur.bottom - next.top) / Math.max(cur.height, 1);
      p = Math.max(0, Math.min(1, p));
      cards[i].style.setProperty("--p", p.toFixed(3));
    }
  }
  function requestStack() { if (!ticking) { ticking = true; requestAnimationFrame(updateStack); } }
  if (cards.length && !reduceMotion) {
    window.addEventListener("scroll", requestStack, { passive: true });
    window.addEventListener("resize", requestStack);
    updateStack();
  }

  /* ---------- Luz suave que acompanha o cursor ---------- */
  if (finePointer && !reduceMotion) {
    document.querySelectorAll(".btn, .visa").forEach(function (el) {
      el.addEventListener("pointermove", function (ev) {
        var r = el.getBoundingClientRect();
        el.style.setProperty("--mx", (ev.clientX - r.left) + "px");
        el.style.setProperty("--my", (ev.clientY - r.top) + "px");
      });
    });
  }

  /* ---------- Revelação suave ao rolar ---------- */
  var reveals = document.querySelectorAll(".reveal");
  reveals.forEach(function (el) {
    var siblings = Array.prototype.filter.call(el.parentElement.children, function (c) { return c.classList.contains("reveal"); });
    var idx = siblings.indexOf(el);
    if (idx > 0) el.style.setProperty("--d", Math.min(idx, 5) * 90 + "ms");
  });
  if ("IntersectionObserver" in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add("is-visible"); io.unobserve(entry.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("is-visible"); });
  }
})();
